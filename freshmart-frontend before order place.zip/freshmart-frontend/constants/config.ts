// config.ts
export const backendIp = '192.168.1.69'; // Replace with your backend IP and port
