import React from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { useAppSelector, useAppDispatch } from '../redux/hooks';
import { removeFromCart, clearCart } from '../redux/slices/cartSlice';
import { useRouter } from 'expo-router';

export default function Cart() {
  const items = useAppSelector(state => state.cart.items);
  const dispatch = useAppDispatch();
  const router = useRouter();

  const totalPrice = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text style={styles.name}>{item.name} x {item.quantity}</Text>
      <Text style={styles.price}>${(item.price * item.quantity).toFixed(2)}</Text>
      <TouchableOpacity
        onPress={() => dispatch(removeFromCart(item.id))}
        style={styles.removeBtn}
      >
        <Text style={styles.removeText}>Remove</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Your Cart</Text>
      {items.length === 0 ? (
        <Text>Your cart is empty.</Text>
      ) : (
        <>
          <FlatList
            data={items}
            keyExtractor={item => item.id.toString()}
            renderItem={renderItem}
          />

          <View style={styles.totalContainer}>
            <Text style={styles.totalLabel}>Total:</Text>
            <Text style={styles.totalAmount}>${totalPrice.toFixed(2)}</Text>
          </View>

          <TouchableOpacity
            style={styles.clearBtn}
            onPress={() => dispatch(clearCart())}
          >
            <Text style={styles.clearText}>Clear Cart</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.checkoutBtn}
            onPress={() => router.push('/checkout')}
          >
            <Text style={styles.checkoutText}>Checkout</Text>
          </TouchableOpacity>
        </>
      )}
      <TouchableOpacity
        style={styles.backBtn}
        onPress={() => router.push('/')}
      >
        <Text style={styles.backText}>Back to Products</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#F0FDF4' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    alignItems: 'center',
  },
  name: { fontSize: 16 },
  price: { fontWeight: 'bold', fontSize: 16 },
  removeBtn: { backgroundColor: '#dc2626', borderRadius: 6, paddingHorizontal: 8 },
  removeText: { color: 'white' },
  totalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
    marginBottom: 8,
    paddingHorizontal: 8,
  },
  totalLabel: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#166534',
  },
  totalAmount: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#16a34a',
  },
  clearBtn: {
    marginTop: 20,
    backgroundColor: '#16a34a',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  clearText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
  checkoutBtn: {
    marginTop: 12,
    backgroundColor: '#2563eb',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  checkoutText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
  backBtn: {
    marginTop: 20,
    alignItems: 'center',
  },
  backText: {
    color: '#2563eb',
    fontWeight: 'bold',
  },
});
