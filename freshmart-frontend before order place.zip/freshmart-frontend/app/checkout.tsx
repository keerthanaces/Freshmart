import React from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";
import { useAppSelector, useAppDispatch } from "../redux/hooks";
import {
  removeFromCart,
  updateQuantity,
  clearCart,
} from "../redux/slices/cartSlice";

export default function Checkout() {
  const cartItems = useAppSelector((state) => state.cart.items);
  const dispatch = useAppDispatch();

  const totalPrice = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const handleRemove = (id: number) => {
    dispatch(removeFromCart(id));
  };

  const changeQuantity = (id: number, newQty: number) => {
    if (newQty < 1) return;
    dispatch(updateQuantity({ id, quantity: newQty }));
  };

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      Alert.alert("Your cart is empty!");
      return;
    }
    // TODO: integrate payment or order submission here
    Alert.alert(
      "Checkout Successful",
      `Your order totaling $${totalPrice.toFixed(2)} has been placed.`
    );
    dispatch(clearCart());
  };

  const renderItem = ({ item }: { item: typeof cartItems[0] }) => (
    <View style={styles.itemContainer}>
      <Text style={styles.itemName}>{item.name}</Text>
      <View style={styles.qtyContainer}>
        <TouchableOpacity
          style={styles.qtyBtn}
          onPress={() => changeQuantity(item.id, item.quantity - 1)}
        >
          <Text style={styles.qtyBtnText}>-</Text>
        </TouchableOpacity>

        <Text style={styles.qtyText}>{item.quantity}</Text>

        <TouchableOpacity
          style={styles.qtyBtn}
          onPress={() => changeQuantity(item.id, item.quantity + 1)}
        >
          <Text style={styles.qtyBtnText}>+</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.itemPrice}>${(item.price * item.quantity).toFixed(2)}</Text>
      <TouchableOpacity onPress={() => handleRemove(item.id)}>
        <Text style={styles.removeText}>Remove</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Checkout</Text>

      {cartItems.length === 0 ? (
        <Text style={styles.emptyText}>Your cart is empty.</Text>
      ) : (
        <>
          <FlatList
            data={cartItems}
            renderItem={renderItem}
            keyExtractor={(item) => item.id.toString()}
          />

          <View style={styles.totalContainer}>
            <Text style={styles.totalText}>Total:</Text>
            <Text style={styles.totalAmount}>${totalPrice.toFixed(2)}</Text>
          </View>

          <TouchableOpacity style={styles.checkoutBtn} onPress={handleCheckout}>
            <Text style={styles.checkoutBtnText}>Place Order</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "#F0FDF4",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 16,
    color: "#166534",
    alignSelf: "center",
  },
  emptyText: {
    fontSize: 18,
    color: "#6b7280",
    textAlign: "center",
    marginTop: 40,
  },
  itemContainer: {
    backgroundColor: "white",
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    elevation: 2,
  },
  itemName: {
    flex: 2,
    fontWeight: "600",
    fontSize: 16,
    color: "#166534",
  },
  qtyContainer: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
    justifyContent: "center",
  },
  qtyBtn: {
    backgroundColor: "#16a34a",
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  qtyBtnText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 18,
  },
  qtyText: {
    marginHorizontal: 8,
    fontSize: 16,
  },
  itemPrice: {
    flex: 1,
    fontWeight: "bold",
    fontSize: 16,
    color: "#16a34a",
    textAlign: "right",
  },
  removeText: {
    color: "#ef4444",
    marginLeft: 12,
    fontWeight: "600",
  },
  totalContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 24,
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  totalText: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#166534",
  },
  totalAmount: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#16a34a",
  },
  checkoutBtn: {
    backgroundColor: "#16a34a",
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
  },
  checkoutBtnText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
});
