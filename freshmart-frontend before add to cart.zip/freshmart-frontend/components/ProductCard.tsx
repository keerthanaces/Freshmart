import React from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";
import { useRouter } from "expo-router";

export interface ProductCardProps {
  id: number | string;
  name: string;
  price: number;
  images?: string[];
  category?: string;
}

export default function ProductCard({
  id,
  name,
  price,
  images,
  category,
}: ProductCardProps) {
  const router = useRouter();

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={() => router.push(`/product/${id}`)}
    >
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.imageContainer}
      >
        {images && images.length > 0 ? (
          images.map((img, i) => (
            <Image
              key={i}
              source={{ uri: `http://localhost:8080/images/${img}` }}
              style={styles.image}
              resizeMode="cover"
            />
          ))
        ) : (
          <View style={[styles.image, styles.noImage]}>
            <Text>No Image</Text>
          </View>
        )}
      </ScrollView>

      <Text style={styles.name} numberOfLines={1}>{name}</Text>
      <Text style={styles.price}>${price.toFixed(2)}</Text>
      {category && <Text style={styles.category}>{category}</Text>}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 220,            // Increased width
    backgroundColor: "white",
    padding: 16,           // More padding for spaciousness
    margin: 8,             // Slightly bigger margin
    borderRadius: 12,
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  imageContainer: {
    flexDirection: "row",
    marginBottom: 12,
  },
  image: {
    height: 140,           // Larger images
    width: 140,
    borderRadius: 12,
    marginRight: 12,
  },
  noImage: {
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#e5e7eb",
  },
  name: {
    fontWeight: "700",
    fontSize: 18,          // Bigger font
    marginBottom: 4,
  },
  price: {
    color: "#16a34a",
    fontWeight: "bold",
    fontSize: 16,          // Bigger font
    marginBottom: 6,
  },
  category: {
    color: "#6b7280",
    fontSize: 14,
  },
});
